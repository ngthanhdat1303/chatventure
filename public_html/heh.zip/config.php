<?php
$DBHOST = "localhost"; // Set your database host here
$DBUSER = "id16066561_lqdchatventure"; // Set your database user here
$DBNAME = "id16066561_lqd_chatventure"; // Set your database name here
$DBPW   =  "Idk123hmm2202^^"; // Set your database password here
$BOT_ID = "60163601b115ad5710021922";
$TOKEN  = "iCPg4Xzno2AgKSAFcQhvdq5TYvETeDq94WTyVyk5I77zAIN7JgjyOD4ixOWoHBzH";

$BLOCK_NAME = "lqd_chat";
$JSON = "lqd_text";
$BLOCK_IMAGE = "lqd_image";
$BLOCK_VOID = "lqd_void";
$BLOCK_VIDEO = "lqd_video";
$BLOCK_FILE = "lqd_file";

?>
